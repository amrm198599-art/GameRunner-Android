package com.example.gamerunner

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var gamesDir: File
    @Volatile private var isolated = false
    private var playing = false

    private val host = "appassets.androidplatform.net"
    private val home = "https://$host/assets/index.html"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importZip(uri)
    }

    private val mimes = mapOf(
        "html" to "text/html", "htm" to "text/html", "js" to "text/javascript",
        "mjs" to "text/javascript", "css" to "text/css", "json" to "application/json",
        "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg",
        "gif" to "image/gif", "webp" to "image/webp", "svg" to "image/svg+xml",
        "ico" to "image/x-icon", "mp3" to "audio/mpeg", "ogg" to "audio/ogg",
        "wav" to "audio/wav", "m4a" to "audio/mp4", "wasm" to "application/wasm",
        "woff" to "font/woff", "woff2" to "font/woff2", "ttf" to "font/ttf",
        "otf" to "font/otf", "mp4" to "video/mp4", "webm" to "video/webm",
        "txt" to "text/plain", "xml" to "application/xml"
    )

    private fun mimeOf(n: String) = mimes[n.substringAfterLast('.', "").lowercase()] ?: "application/octet-stream"
    private fun isText(m: String) = m.startsWith("text/") || m.contains("json") || m.contains("javascript") || m.contains("xml")

    private fun resp(stream: InputStream, name: String, iso: Boolean): WebResourceResponse {
        val m = mimeOf(name)
        val h = HashMap<String, String>()
        h["Access-Control-Allow-Origin"] = "*"
        h["Cache-Control"] = "no-cache"
        if (iso) {
            h["Cross-Origin-Opener-Policy"] = "same-origin"
            h["Cross-Origin-Embedder-Policy"] = "require-corp"
            h["Cross-Origin-Resource-Policy"] = "same-origin"
        }
        return WebResourceResponse(m, if (isText(m)) "utf-8" else null, 200, "OK", h, stream)
    }

    private fun notFound() =
        WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), "".byteInputStream())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gamesDir = File(filesDir, "games").apply { mkdirs() }
        gamesDir.listFiles()?.filter { it.name.startsWith(".tmp_") }?.forEach { it.deleteRecursively() }

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
        }
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url
                if (u.host != host) return null
                val p = u.path ?: return notFound()
                return try {
                    when {
                        p.startsWith("/assets/") -> {
                            val n = p.removePrefix("/assets/")
                            resp(this@MainActivity.assets.open(n), n, false)
                        }
                        p.startsWith("/games/") -> {
                            val f = File(gamesDir, p.removePrefix("/games/")).canonicalFile
                            if (!f.path.startsWith(gamesDir.canonicalPath + File.separator) || !f.isFile) notFound()
                            else resp(FileInputStream(f), f.name, isolated)
                        }
                        else -> notFound()
                    }
                } catch (e: Exception) {
                    notFound()
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl(home)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (playing) goHome() else finish()
            }
        })
    }

    private fun immersive(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, web)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun goHome() {
        playing = false
        immersive(false)
        web.loadUrl(home)
    }

    private fun js(s: String) = runOnUiThread { web.evaluateJavascript(s, null) }

    private fun findEntry(dir: File): String? {
        val base = dir.canonicalPath
        val htmls = dir.walkTopDown()
            .filter { it.isFile && (it.extension.equals("html", true) || it.extension.equals("htm", true)) }
            .map { it.canonicalPath.removePrefix(base + File.separator).replace(File.separatorChar, '/') }
            .toList()
        return htmls.sortedWith(
            compareByDescending<String> { it.equals("index.html", true) || it.endsWith("/index.html", true) }
                .thenBy { s -> s.count { it == '/' } }
        ).firstOrNull()
    }

    private fun safeName(n: String) = n.isNotEmpty() && !n.contains('/') && !n.contains("..") && !n.startsWith(".")

    private fun importZip(uri: Uri) {
        Thread {
            var tmp: File? = null
            try {
                var disp = "game"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0) disp = c.getString(i) ?: "game"
                    }
                }
                var name = disp.replace(Regex("(?i)\\.zip$"), "")
                    .replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").trim().trimStart('.')
                if (name.isEmpty()) name = "game"
                if (File(gamesDir, name).exists()) name += "_" + (System.currentTimeMillis() % 100000)

                val t = File(gamesDir, ".tmp_" + System.currentTimeMillis()).also { it.mkdirs() }
                tmp = t
                val tmpCanon = t.canonicalPath
                var count = 0
                val buf = ByteArray(65536)
                contentResolver.openInputStream(uri)!!.use { ins ->
                    ZipInputStream(ins.buffered()).use { zin ->
                        var e = zin.nextEntry
                        while (e != null) {
                            val n = e.name
                            if (!e.isDirectory && !n.startsWith("__MACOSX") && !n.substringAfterLast('/').startsWith("._")) {
                                val out = File(t, n).canonicalFile
                                if (out.path.startsWith(tmpCanon + File.separator)) {
                                    out.parentFile?.mkdirs()
                                    out.outputStream().use { o ->
                                        while (true) {
                                            val r = zin.read(buf)
                                            if (r < 0) break
                                            o.write(buf, 0, r)
                                        }
                                    }
                                    count++
                                    if (count % 20 == 0) js("window.onProgress&&onProgress($count)")
                                }
                            }
                            zin.closeEntry()
                            e = zin.nextEntry
                        }
                    }
                }
                val kids = t.listFiles()?.filter { !it.name.startsWith("__MACOSX") } ?: emptyList()
                val root = if (kids.size == 1 && kids[0].isDirectory) kids[0] else t
                if (findEntry(root) == null) throw Exception("لا يوجد ملف HTML داخل الملف المضغوط")
                val target = File(gamesDir, name)
                if (!root.renameTo(target)) throw Exception("تعذّر حفظ اللعبة")
                t.deleteRecursively()
                js("window.onImported&&onImported(${JSONObject.quote(name)})")
            } catch (e: Exception) {
                tmp?.deleteRecursively()
                js("window.onImportError&&onImportError(${JSONObject.quote(e.message ?: "خطأ غير معروف")})")
            }
        }.start()
    }

    inner class Bridge {
        @JavascriptInterface
        fun pickZip() {
            runOnUiThread {
                picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            }
        }

        @JavascriptInterface
        fun listGames(): String {
            val arr = JSONArray()
            gamesDir.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }
                ?.sortedBy { it.name }?.forEach { d ->
                    val e = findEntry(d) ?: return@forEach
                    val size = d.walkTopDown().filter { it.isFile }.sumOf { it.length() }
                    arr.put(JSONObject().put("name", d.name).put("entry", e).put("size", size))
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun play(name: String, entry: String, iso: Boolean) {
            if (!safeName(name)) return
            runOnUiThread {
                isolated = iso
                playing = true
                immersive(true)
                val path = entry.split('/').joinToString("/") { Uri.encode(it) }
                web.loadUrl("https://$host/games/${Uri.encode(name)}/$path")
            }
        }

        @JavascriptInterface
        fun remove(name: String) {
            if (safeName(name)) File(gamesDir, name).deleteRecursively()
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
